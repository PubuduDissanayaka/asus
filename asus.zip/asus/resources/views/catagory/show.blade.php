@extends('layouts.app')

@section('content')
    {{-- <div class="container-fluid">
    <h1>{{$data->name}}</h1>

    <a href="/catagory">
        <button class="btn btn-primary">Back</button>
    </a>
    </div> --}}

    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                {{$data->name}}
                <br>
                <a href="/catagory">
                    <button class="btn btn-danger">Back</button>
                </a>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
@endsection