<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        <?php echo Form::open(['route' => 'catagory.store']); ?>

            <input type="text" name="catname" class="form-control" placeholder="Catagory Name" required>
            <br>
            <input type="submit" class="form-control btn btn-info" value="Create">
            <?php echo Form::close(); ?>

    </div>
    <div class="col-sm-4"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>