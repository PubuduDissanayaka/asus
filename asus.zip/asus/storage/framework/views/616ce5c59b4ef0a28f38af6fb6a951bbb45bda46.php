<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('layouts.slide', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
    <br>
    <a href="/catagory/create">
        <button class="btn btn-info">Create Page</button>
    </a>
    <br>
    <div class="container">
        
        <?php if(count($data)>0): ?>
        <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <div class="card" style="width: 18rem;">
                        <div class="card-body">
                            <a href="catagory/<?php echo e($data->id); ?>">
                                <h5 class="card-title"><?php echo e($data->name); ?></h5>
                            </a>
                            
                        <p class="card-text"><?php echo e($data->created_at); ?></p>
                        
                        </div>
                    </div>
                    <br>
                </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php else: ?>
            <h2>no data</h2>
        <?php endif; ?>
        
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>